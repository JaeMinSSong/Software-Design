package com.example.fmproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Headquarter_MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_headquarter_main);
    }
}