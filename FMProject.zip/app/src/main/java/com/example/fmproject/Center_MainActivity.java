package com.example.fmproject;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import org.json.JSONException;
import org.json.JSONObject;
import android.util.Log;
import android.widget.EditText;
import android.widget.Toast;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class Center_MainActivity extends AppCompatActivity {

    private Button profileButton;
    private Button equipmentButton;
    private Button firehydrantButton;
    private Button employeeButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_center_main);

        // Get the userName from the intent
        Intent intent = getIntent();
        String userID = intent.getStringExtra("userID");

        // Create and set the profile button
        profileButton = findViewById(R.id.btn_Profile);
        profileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open ProfileActivity
                Intent profileIntent = new Intent(Center_MainActivity.this, ProfileActivity.class);
                startActivity(profileIntent);
            }
        });

        // Create and set the equipment button
        equipmentButton = findViewById(R.id.btn_EquipmentList);
        equipmentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open MyEquipmentActivity
                Intent equipmentIntent = new Intent(Center_MainActivity.this, MyEquipmentActivity.class);
                equipmentIntent.putExtra("userID", userID);
                startActivity(equipmentIntent);
            }
        });

        // Create and set the fire extinguisher button
        firehydrantButton = findViewById(R.id.btn_FireHydrantList);
        firehydrantButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open MyFireHydrantActivity
                Intent firehydrantIntent = new Intent(Center_MainActivity.this, MyFireHydrantActivity.class);
                startActivity(firehydrantIntent);
            }
        });

        // Create and set the fire extinguisher button
        employeeButton = findViewById(R.id.btn_EmployeeList);
        employeeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open FindEmployeeActivity
                Intent employeeIntent = new Intent(Center_MainActivity.this, FindEmployeeActivity.class);
                startActivity(employeeIntent);
            }
        });

    }
}
