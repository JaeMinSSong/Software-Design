package com.example.fmproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MyFireHydrantActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_fire_hydrant);
    }
}