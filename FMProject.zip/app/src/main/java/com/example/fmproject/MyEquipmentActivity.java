package com.example.fmproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MyEquipmentActivity extends AppCompatActivity {

    private ListView lvEquipName;
    private Button btnRegisterEquipment;

    private ArrayList<String> equipNameList;
    private ArrayAdapter<String> equipNameAdapter;
    private String userID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_equipment);

        Intent intent = getIntent();
        userID = intent.getStringExtra("userID");

        lvEquipName = findViewById(R.id.lv_EquipName);
        btnRegisterEquipment = findViewById(R.id.btnRegisterEquipment);

        equipNameList = new ArrayList<>();
        equipNameAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_single_choice, equipNameList);
        lvEquipName.setAdapter(equipNameAdapter);
        lvEquipName.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        // Retrieve the equipName list from the server
        retrieveEquipNameList();

        lvEquipName.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                String selectedEquipName = equipNameList.get(position);
                Toast.makeText(MyEquipmentActivity.this, "Selected EquipName: " + selectedEquipName, Toast.LENGTH_SHORT).show();
            }
        });

        btnRegisterEquipment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MyEquipmentActivity.this, RegisterEquipmentActivity.class);
                startActivity(intent);
            }
        });
    }

    private void retrieveEquipNameList() {
        String url = "http://fmproject.dothome.co.kr/RetrieveEquipName.php";

        StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray jsonArray = new JSONArray(response);

                    for (int i = 0; i < jsonArray.length(); i++) {
                        String equipName = jsonArray.getString(i);
                        equipNameList.add(equipName);
                    }

                    equipNameAdapter.notifyDataSetChanged();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MyEquipmentActivity.this, "Failed to connect to the server", Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("userID", userID);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }
}
