package com.example.fmproject;

import com.android.volley.AuthFailureError;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class MyEquipmentRequest extends StringRequest {

    // Server URL for equipment retrieval
    final static private String URL = "http://fmproject.dothome.co.kr/MyEquipmentList.php";

    public MyEquipmentRequest(Response.Listener<String> listener) {
        super(Method.POST, URL, listener, null);
    }

    @Override
    protected Map<String, String> getParams() throws AuthFailureError {
        // No parameters needed for equipment retrieval
        return new HashMap<>();
    }
}
