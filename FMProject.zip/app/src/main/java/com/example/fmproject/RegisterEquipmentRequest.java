package com.example.fmproject;

import com.android.volley.AuthFailureError;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class RegisterEquipmentRequest extends StringRequest {

    // Server URL setting (PHP file integration)
    final static private String URL = "http://fmproject.dothome.co.kr/RegisterEquipment.php";
    private Map<String, String> map;

    public RegisterEquipmentRequest(String equipName, String equipClass, String equipModelNum, int equipPurchaseDate, int equipManufactureDate, int equipNum, String equipManagerName, String equipManagerID, String equipStatus, Response.Listener<String> listener) {
        super(Method.POST, URL, listener, null);

        map = new HashMap<>();
        map.put("equipName", equipName);
        map.put("equipClass", equipClass);
        map.put("equipModelNum", equipModelNum);
        map.put("equipPurchaseDate", String.valueOf(equipPurchaseDate));
        map.put("equipManufactureDate", String.valueOf(equipManufactureDate));
        map.put("equipNum", String.valueOf(equipNum));
        map.put("equipManagerName", equipManagerName);
        map.put("equipManagerID", equipManagerID);
        map.put("equipStatus", equipStatus);
    }

    @Override
    protected Map<String, String> getParams() throws AuthFailureError {
        return map;
    }
}
