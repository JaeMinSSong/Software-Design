package com.example.fmproject;

import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;
public class RegisterEquipmentActivity extends AppCompatActivity {

    private EditText et_equipName, et_equipClass, et_equipModelNum, et_equipPurchaseDate, et_equipManufactureDate, et_equipNum, et_equipManagerName, et_equipManagerID;
    private Spinner spinner_status;
    private Button button_register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_equipment);

        et_equipName = findViewById(R.id.et_equipName);
        et_equipClass = findViewById(R.id.et_equipClass);
        et_equipModelNum = findViewById(R.id.et_equipModelNum);
        et_equipPurchaseDate = findViewById(R.id.et_equipPurchaseDate);
        et_equipManufactureDate = findViewById(R.id.et_equipManufactureDate);
        et_equipNum = findViewById(R.id.et_equipNum);
        et_equipManagerName = findViewById(R.id.et_equipManagerName);
        et_equipManagerID = findViewById(R.id.et_equipManagerID);
        spinner_status = findViewById(R.id.spinner_status);
        button_register = findViewById(R.id.button_register);

        String[] statusOptions = {"가용", "불용"};
        // Creating adapter for spinner
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, statusOptions);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_status.setAdapter(spinnerAdapter);

        // Spinner item selection listener
        spinner_status.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                String equipStatus = adapterView.getItemAtPosition(position).toString();
                if (equipStatus.equals("가용")) {
                    equipStatus = "가용"; // 추가한 코드
                }
                if (equipStatus.equals("불용")) {
                    equipStatus = "불용"; // 추가한 코드
                }
                else {
                    equipStatus = ""; // 추가한 코드
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                // Do nothing
            }
        });

        button_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get user input
                String equipName = et_equipName.getText().toString();
                String equipClass = et_equipClass.getText().toString();
                String equipModelNum = et_equipModelNum.getText().toString();
                int equipPurchaseDate = Integer.parseInt(et_equipPurchaseDate.getText().toString());
                int equipManufactureDate = Integer.parseInt(et_equipManufactureDate.getText().toString());
                int equipNum = Integer.parseInt(et_equipNum.getText().toString());
                String equipManagerName = et_equipManagerName.getText().toString();
                String equipManagerID = et_equipManagerID.getText().toString();
                String equipStatus = spinner_status.getSelectedItem().toString();

                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            boolean success = jsonObject.getBoolean("success");
                            if (success) {
                                Toast.makeText(getApplicationContext(), "장비 등록에 성공하였습니다.", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(RegisterEquipmentActivity.this, MyEquipmentActivity.class);
                                startActivity(intent);
                            } else {
                                Toast.makeText(getApplicationContext(), "장비 등록에 실패하였습니다.", Toast.LENGTH_SHORT).show();
                                return;
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };

                RegisterEquipmentRequest registerEquipementRequest = new RegisterEquipmentRequest(equipName, equipClass, equipModelNum, equipPurchaseDate, equipManufactureDate, equipNum, equipManagerName, equipManagerID, equipStatus, responseListener);
                RequestQueue queue = Volley.newRequestQueue(RegisterEquipmentActivity.this);
                queue.add(registerEquipementRequest);
            }
        });
    }
}

